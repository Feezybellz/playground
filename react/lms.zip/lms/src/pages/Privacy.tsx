// src/pages/Privacy.tsx
import React from 'react';


const Privacy: React.FC = () => {
  return (
    <div>
      <h1>Privacy Policy</h1>
      <p>...</p>
    </div>
  );
};

export default Privacy;