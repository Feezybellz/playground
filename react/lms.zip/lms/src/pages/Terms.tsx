// src/pages/Terms.tsx
import React from 'react';

const Terms: React.FC = () => {
  return (
    <div>
      <h1>Terms of Service</h1>
      <p>...</p>
    </div>
  );
};

export default Terms;